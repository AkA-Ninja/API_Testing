package Day8;

import static io.restassured.RestAssured.given;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
public class GetUser {
	
	@Test
	public void getUser(ITestContext context) {
		
		String bearerToken="d86a4608213ed4305e856e696ac9d00461205a2594adf676a7690b5fc68d8ceb";
		int id=(int) context.getAttribute("user_id");
		
		given()
		.contentType(ContentType.JSON)
		.pathParam("id",id) //this id should come from createUser class 
		.headers("Authorization","Bearer "+bearerToken)
		
		.when()
		.get("https://gorest.co.in/public/v2/users/{id}")
		.then()
		.statusCode(200)
		.log().all();
	}
}
