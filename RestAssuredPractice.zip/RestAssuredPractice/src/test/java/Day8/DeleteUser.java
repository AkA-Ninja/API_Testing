package Day8;
import static io.restassured.RestAssured.given;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
public class DeleteUser {
	@Test
	public void deleteUser(ITestContext context) {
		
		
		String bearerToken="d86a4608213ed4305e856e696ac9d00461205a2594adf676a7690b5fc68d8ceb";
		
		
		int id=(Integer)context.getAttribute("user_id");
		given()
		.contentType(ContentType.JSON)
		.pathParam("id",id)
		.headers("Authorization","Bearer "+bearerToken)
		.when()
		.delete("https://gorest.co.in/public/v2/users/{id}")
		.then()
		.statusCode(204)
		.log().all();
	}
}
