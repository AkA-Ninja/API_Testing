package Day8;

import static io.restassured.RestAssured.given;

import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.http.ContentType;
public class UpdateUser {
	@Test
	public void update_user(ITestContext context) {
		Faker faker = new Faker();
		JSONObject data=new JSONObject();
		String bearerToken="d86a4608213ed4305e856e696ac9d00461205a2594adf676a7690b5fc68d8ceb";
		data.put("name", faker.name().fullName());
		data.put("email", faker.internet().emailAddress());
		data.put("gender", "female");
		data.put("status", "active");
		int id=(int)context.getAttribute("user_id");
		given()
		.contentType(ContentType.JSON)
		.headers("Authorization","Bearer "+bearerToken)
		.pathParam("id", id)
		.body(data.toString())
		
		.when()
		.put("https://gorest.co.in/public/v2/users/{id}")
		.then()
		.statusCode(200)
		.header("Content-Type", "application/json; charset=utf-8")
		.log().all();
	}
}
