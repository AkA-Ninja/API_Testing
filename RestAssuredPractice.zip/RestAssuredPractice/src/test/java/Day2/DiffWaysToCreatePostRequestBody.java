package Day2;

import org.json.JSONObject;
import org.json.JSONTokener;

/*How many ways we create request body
----------------
1) Hashmap
2) using org.json
3) using POJO (Plain Old Java Object)
4) using external json file*/

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

public class DiffWaysToCreatePostRequestBody {
	//@Test(priority=1)
	void testusingHashMap() {
		//post request using hashmap
		HashMap data = new HashMap();
		data.put("name", "scott");
		data.put("location", "France");
		data.put("phone", "123456734");
		
		String coursearr[]= {"C","C++"};
		data.put("courses", coursearr);
		
		given()
		.contentType("application/json")
		.body(data)
		
		.when()
		.post("http://localhost:3000/students")
		
		.then()
		.statusCode(201)
		.body("name",equalTo("scott"))
		.body("location",equalTo("France"))
		.body("phone",equalTo("123456734"))
		.body("courses[0]",equalTo("C"))
		.body("courses[1]",equalTo("C++"))
		.header("Content-Type", "application/json; charset=utf-8")
		.log().all();
	}
	
	//@Test(priority=2)
	void deleteRecord1() {
		given()
		
		.when()
		.delete("http://localhost:3000/students/4")
		.then()
		.statusCode(404);
	}
	
	//@Test(priority=1)
	void testPostusingOrgJson() {
		//post request using org.json
		
		JSONObject data = new JSONObject();
		data.put("name", "Sam");
		data.put("location", "France");
		data.put("phone", "123456734");
		
		String coursearr[]= {"C","C++"};
		data.put("courses", coursearr);
		
		given()
		.contentType("application/json")
		.body(data.toString())    //in order to use json library we need to convert the json data in string format but the rest is same as hashmap
		
		.when()
		.post("http://localhost:3000/students")
		
		.then()
		.statusCode(201)
		.body("name",equalTo("scott"))
		.body("location",equalTo("France"))
		.body("phone",equalTo("123456734"))
		.body("courses[0]",equalTo("C"))
		.body("courses[1]",equalTo("C++"))
		.header("Content-Type", "application/json; charset=utf-8")
		.log().all();
	}
	//@Test(priority=2)
	void deleteRecord2() {
		given()
		
		.when()
		.delete("http://localhost:3000/students/4")
		.then()
		.statusCode(200);
	}
	
//	@Test(priority=1)
	void testPostusingPOJO() {
		//post request using POJO class.For POJO class we need to use setter and getter method
		
		POJO_postRequest data = new POJO_postRequest();
		
		data.setName("scott");
		data.setLocation("France");
		data.setPhone("123456789098");
		String Coursearr[]= {"C","C++"};
		data.setCourses(Coursearr);
		
		given()
		.contentType("application/json")
		.body(data)   
		
		.when()
		.post("http://localhost:3000/students")
		
		.then()
		.statusCode(201)
		.body("name",equalTo("scott"))
		.body("location",equalTo("France"))
		.body("phone",equalTo("123456789098"))
		.body("courses[0]",equalTo("C"))
		.body("courses[1]",equalTo("C++"))
		.header("Content-Type", "application/json; charset=utf-8")
		.log().all();
	}
	//@Test(priority=1)
	void deleteRecord3() {
		given()
		
		.when()
		.delete("http://localhost:3000/students/9")
		.then()
		.statusCode(200);
	}
	
	@Test(priority=1)
	void testPostusingExternalJSONFile() throws FileNotFoundException {
		//post request using External JSON file
		File f = new File("C:\\Users\\2229538\\eclipse-workspace\\RestAssuredPractice\\src\\test\\resources\\Body.json");
		FileReader fr = new FileReader(f);
		JSONTokener jt = new JSONTokener(fr);
		
		JSONObject data = new JSONObject(jt);
		
		given()
		.contentType(ContentType.JSON)
		.body(data.toString())   //in order to use json data we need to convert the json data in string format but the rest is same as hashmap
		
		.when()
		.post("http://localhost:3000/students")
		
		.then()
		.statusCode(201)
		.body("name",equalTo("scott"))
		.body("location",equalTo("France"))
		.body("phone",equalTo("123456789098"))
		.body("courses[0]",equalTo("C"))
		.body("courses[1]",equalTo("C++"))
		.header("Content-Type", "application/json; charset=utf-8")
		.log().all();
	}
	@Test(priority=1)
	void deleteRecord4() {
		given()
		
		.when()
		.delete("http://localhost:3000/students/8")
		.then()
		.statusCode(200);
	}
}
