package Day5;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
public class FileUploadAndDownloadAPI {

	//@Test
	public void singleFileUpload() {
		File myfile = new File("C:\\Users\\2229538\\Downloads\\API Testing\\RestAssured\\20.parsing XML Response,file-upload&download API\\Day15.txt");//as this is a java library we don't need to write this inside the given section
		given()
		.multiPart("file",myfile)//this one
		.contentType("multipart/form-data")//and this one is important inorder to upload a file because one is hoding the variable and other one is holding which type of contect we are passing in postman in the body section we select form-data which is a multipart og the body
		.when()
		.post("http://localhost:8080/uploadFile")
		.then()
		.statusCode(200)
		.body("fileName",equalTo("Day15.txt"))
		.log().all();
	}
	//@Test
	public void MultipleFileUpload() {
		File myfile1 = new File("C:\\Users\\2229538\\Downloads\\API Testing\\RestAssured\\20.parsing XML Response,file-upload&download API\\Day15.txt");//as this is a java library we don't need to write this inside the given section
		File myfile2 = new File("C:\\Users\\2229538\\Downloads\\API Testing\\RestAssured\\20.parsing XML Response,file-upload&download API\\file-upload-RestAPI.jar");
		given()
		.multiPart("files",myfile1) //instead of writing this too many times we can store the file variables into file type of array eg. File filearr[]={myfile1,myfile2} and then pass it in multipart as a single variable eg. .multiPart(files,filearr) it won't work all the time it depends on how developer developed the API's
		.multiPart("files",myfile2)
		.contentType("multipart/form-data")
		.when()
		.post("http://localhost:8080/uploadMultipleFiles")
		.then()
		.statusCode(200)
		.body("[0].fileName",equalTo("Day15.txt"))
		.body("[1].fileName",equalTo("file-upload-RestAPI.jar"))
		.log().all();
	}
	
	@Test
	public void downloadFile() {
		given()
		
		.when()
		.get("http://localhost:8080/downloadFile/Day15.txt")
		
		.then()
		.statusCode(200)
		.log().body();
	}
}
