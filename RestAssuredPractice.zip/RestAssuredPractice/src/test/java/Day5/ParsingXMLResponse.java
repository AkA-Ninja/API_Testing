package Day5;
	
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
public class ParsingXMLResponse {
	
	@Test(priority=1)
	public void testXMLresponse() {
		//Approach 1 without using response variable
		given()
		
		.when()
		.get("http://restapi.adequateshop.com/api/Traveler?page=1")
		
		.then()
		.statusCode(200)
		.header("Content-Type", "application/xml; charset=utf-8")
		.body("TravelerinformationResponse.page",equalTo("1"))//here we are validating the page number so we are using absolute xmlpath//in xml response we can't use jsonpath so we have to use xpath or xmlpath
		//.body("TravelerinformationResponse.total_pages",equalTo("2700"))
		.body("TravelerinformationResponse.travelers.Travelerinformation[0].name",equalTo("Developer"));
	}
	@Test(priority=2)
	public void testXMLResponse2() {
		//Approach2 using Response variable instead of .then() function so we can do more validations
		
		Response res=given()
				
				.when()
				.get("http://restapi.adequateshop.com/api/Traveler?page=1");
		
		Assert.assertEquals(res.getStatusCode(), 200);
		Assert.assertEquals(res.header("Content-Type"),"application/xml; charset=utf-8");
		
		String pagenum=res.xmlPath().get("TravelerinformationResponse.page").toString();
		Assert.assertEquals(pagenum, "1");
		
		String travelerName=res.xmlPath().get("TravelerinformationResponse.travelers.Travelerinformation[0].name").toString(); //instead of json path we are using xml path
		Assert.assertEquals(travelerName, "Developer");
	}
	@Test(priority=3)
	public void testXMLResponse3() {
		//Approach 3 using response variable and xmlpath class we can do more validation than we usually do in .then() section
		Response res = given()
				
		.when()
		.get("http://restapi.adequateshop.com/api/Traveler?page=1");
		
		XmlPath xmlobj=new XmlPath(res.asString());  //instead of jsonobject class we are using xmlpath class because the response we are getting from this website it is in xml format and tostring is to convert only data into string and asstring is meant to convert the whole json or xml response into string
		
		//Verify total number of travelers
		List<String>travelers=xmlobj.getList("TravelerinformationResponse.travelers.Travelerinformation");  //here we are storing all the travelers information of 1st page in a list
		Assert.assertEquals(travelers.size(),10);
		
		//verify if name is present inside the xml page or not it could be present anywhere inside the page and inside any node
		boolean status=false;
		List<String>travelersName=xmlobj.getList("TravelerinformationResponse.travelers.Travelerinformation.name");
		for(String travelername:travelersName) {
			if(travelername.equals("Developer"))
			{
				status=true;
				break;
			}
		}
		Assert.assertEquals(status, true);
	}
}
