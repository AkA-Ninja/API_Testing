package Day7;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class Temporary_FakeDataGenerator {
	
	@Test
	public void generateTestDummyData() {
		Faker faker=new Faker();
		
		String fullname=faker.name().fullName();
		String firstname=faker.name().firstName();
		String lastname=faker.name().lastName();
		
		String username=faker.name().username();
		String password=faker.internet().password();
		
		String phoneNumber=faker.phoneNumber().cellPhone();
		String email=faker.internet().safeEmailAddress();
		
		System.out.println("Full Name:"+fullname);
		System.out.println("First Name:"+firstname);
		System.out.println("Last Name:"+lastname);
		System.out.println("UserName:"+username);
		System.out.println("Password:"+password);
		System.out.println("Phone Number:"+phoneNumber);
		System.out.println("Email Address:"+email);
	}
}
