package Day7;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
public class Authentications {
	@Test(priority=1)
	public void testBasicAuthentication() {
		given()
		.auth().basic("postman", "password")
		.when()
		 .get("https://postman-echo.com/basic-auth")
		.then()
		.statusCode(200)
		.body("authenticated",equalTo(true))
		.log().all();
	}
	@Test(priority=2)
	public void testDigestAuthentication() {
		given()
		.auth().digest("postman", "password")
		.when()
		 .get("https://postman-echo.com/basic-auth")
		.then()
		.statusCode(200)
		.body("authenticated",equalTo(true))
		.log().all();
	}
	@Test(priority=3)
	public void testPreemptiveAuthentication() {
		given()
		.auth().preemptive().basic("postman", "password")
		.when()
		 .get("https://postman-echo.com/basic-auth")
		.then()
		.statusCode(200)
		.body("authenticated",equalTo(true))
		.log().all();
	}
	
	@Test(priority=4)
	public void testBearerTokenAuthentication() {
		String bearer="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";
		given()
		.headers("Authorization","Bearer "+bearer)
		.when()
		.get("https://api.github.com/user/repos")
		.then()
		.statusCode(200)
		.log().all();
	}
	@Test(priority=5)
	public void OAuth1Authentication() {
		given()
		.auth().oauth("consumerKey", "consumerSecret", "accessToken", "tokenSecret")
		.when()
		.get("url")
		.then()
		.statusCode(200)
		.log().all();
	}
	
	@Test(priority=6)
	public void OAuth2Authentication() {
		given()
		.auth().oauth2("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")
		.when()
		.get("https://api.github.com/user/repos")
		.then()
		.statusCode(200)
		.log().all();
	}
	
	@Test(priority=7)
	public void APIKeyAuthentication1() {
		//method1
		given()
		.queryParam("appid", "fe9c5cddb7e01d747b4611c3fc9eaf2c")
		.when()
		.get("api.openweathermap.org/data/2.5/forecast/daily?q=Delhi&units=metric&cnt=7")
		.then()
		.statusCode(200)
		.log().all();
	}
	@Test(priority=8)
	public void APIKeyAuthentication2() {
		given()
		.queryParam("appid", "fe9c5cddb7e01d747b4611c3fc9eaf2c")
		.pathParam("mypath", "data/2.5/forecast/daily")
		.queryParam("q", "Delhi")
		.queryParam("units", "metric")
		.queryParam("cnt", "7")
		.when()
		.get("https://api.openweathermap.org/{mypath}")
		.then()
		.statusCode(200)
		.log().all();
	}
	
}

