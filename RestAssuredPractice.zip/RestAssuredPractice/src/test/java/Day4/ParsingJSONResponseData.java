package Day4;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.apache.commons.logging.Log;
import org.json.JSONArray;
import org.json.JSONObject;
public class ParsingJSONResponseData {
	//@Test(priority=1)
	public void testJSONResponse() {
		//Approach1(using json path to validate one field)
		given()
		.contentType(ContentType.JSON)
		.when()
		.get("http://localhost:3000/store")
		.then()
		.statusCode(200)
		.header("Content-Type", "application/json; charset=utf-8")
		.body("book[3].title",equalTo("The Lord of the Rings"))
		.log().all();
	}
	@Test
	public void testJSONResponse2() {
		//Approach2(by storing response in a variable)
		Response res=given()
		.contentType(ContentType.JSON)  //here we don't need to put this inside double inverted commas
		.when()
		.get("http://localhost:3000/store");
		
		Assert.assertEquals(res.getStatusCode(),200); //instead of then section we are validating using testng assertation by storing the response in a response variable
		Assert.assertEquals(res.getHeader("Content-Type"),"application/json; charset=utf-8");
		
		String bookname=res.jsonPath().get("book[3].title").toString();//we are basically storing a single data in a string variable 
		Assert.assertEquals(bookname, "The Lord of the Rings"); //by this way we can also validate one data at a time from response body
		
		//this is the code for getting every book title of every object using response variable and json object and a for loop
		
		//By using JsonObject class because sometimes array indexes can change their index number such as 0'th element can go to 1st element and 1st one can go to 3 element in order to verify the values we need to use for loop
		
		JSONObject jo=new JSONObject(res.asString());//here we are creating an object of jsonobject class and converting response into String using asString function and assigning that string into another json object so that we can use jsonobject functions
		for(int i=0;i<jo.getJSONArray("book").length();i++)//here we are capturing the whole array in getjsonarray then using .length we are defining the length of the array
		{
			String bookName=jo.getJSONArray("book").getJSONObject(i).get("title").toString();
			System.out.println(bookName);
		}
		
		
		//this is the code for getting every book title of every object using response variable and json object and a for loop and validating using if else statement and assertation
		//search for title of the book validation 1
		boolean status=false;
		for(int i=0;i<jo.getJSONArray("book").length();i++) 
		{
			String booktitle=jo.getJSONArray("book").getJSONObject(i).get("title").toString();
			if(booktitle.equals("The Lord of the Rings"))
			{
				status=true;
				break;
			}
		}
		Assert.assertEquals(status,true);
		
		//validate total price of books
		double totalprice=0;//here we are creating a variable so we can add all the book price into this variable
		for(int i=0;i<jo.getJSONArray("book").length();i++) {
		String price=jo.getJSONArray("book").getJSONObject(i).get("price").toString();
		totalprice=totalprice+Double.parseDouble(price);  //here we are converting the price variable from string to double and adding it into totalprice which we have created earlier through this until the loop is finished the totalprice will store all the book price into it and make addition
		}
		System.out.println("The total price of the books is:"+totalprice);
		
		Assert.assertEquals(totalprice, 53.92);
	}
	
}
