package Day1;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;

/*
 * given()
 * content type,set cookies,add auth,set header info etc(All type of pre-requisites we write here)
 * 
 * When()
 * get,post,put,patch(all type of request we write here)
 * 
 * then()
 * validate status code,headers,cookies,response body(All type of validations we write here)
 */

public class HTTPRequests {
	int id;
	@Test(priority=1)
	public void getUsers() {
		
		given()
		
		.when()
		 .get("https://reqres.in/api/users?page=2")
		 
		 .then()
		 .statusCode(200)
		 .body("page",equalTo(2))
		 .log().all();
	}
	
	@Test(priority=2)
	void createUser() {
		
		HashMap hm = new HashMap();
		
		hm.put("name", "Tathagata");
		hm.put("job", "trainer");
		
		id=given()
		.contentType("application/json")
		.body(hm)
		
		.when()
		.post("https://reqres.in/api/users").jsonPath().getInt("id");
//		.then()
//		.statusCode(201)
//		.log().all();
	}
	
	@Test(priority=3,dependsOnMethods = {"createUser"})
	public void updateUser() {   //for updating we have extracted to id from createUser method using jsondata.get function and we also created a global variable that can be used everywhere
		HashMap hm = new HashMap();
		
		hm.put("name", "Polo");
		hm.put("job", "trainee");
		
		given()
		.contentType("application/json")
		.body(hm)
		
		.when()
		.put("https://reqres.in/api/users/"+id)
		
		.then()
		.statusCode(200)
		.log().all();
	}
	@Test(priority=4,dependsOnMethods = {"updateUser"})
	void deleteUser() {
		given()
		
		.when()
		.delete("https://reqres.in/api/users/"+id)
		
		.then()
		.statusCode(204)
		.log().all();
	}
}
