package Day3;

import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class LoggingDemo {

	@Test
	public void testLogs() {
		given()
		
		.when()
		.get("https://reqres.in/api/users?page=2")
		
		.then()
		.log().all()//this statement prints all the responses including headers cookies body on the console
		.log().body()//this will print only the body response
		.log().headers()//this will print only the headers response
		.log().cookies();//this will print only the cookies response
		
	}
}
