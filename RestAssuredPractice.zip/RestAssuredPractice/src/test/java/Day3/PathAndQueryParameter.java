package Day3;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;


public class PathAndQueryParameter {
	
	@Test(priority=1)
	public void testQueryAndPathParameter() {
		
		
		given()
		.pathParam("mypath", "users")
		.queryParam("page",2)   //as these two are part of the url so we don't need have to specify these two inside the http request but we have to use the path param
		.queryParam("id", 5)
		
		.when()
		.get("https://reqres.in/api/{mypath}")
		
		.then()
		.statusCode(200)
		.log().all();
	}
}
