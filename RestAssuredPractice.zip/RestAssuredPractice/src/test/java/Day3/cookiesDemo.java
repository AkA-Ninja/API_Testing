package Day3;


import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;
public class cookiesDemo {
	
	//@Test
	public void testcookies() {
		given()
		
		.when()
		.get("https://www.google.com/")
		
		.then()
		.cookie("AEC","AUEFqZdn-12SH1B77F9PbZjowhXUJtahXKe42K3GXeaDTPTIZ2TVBbp6rxU")
		.log().all();
	}
	@Test
	public void cookiesInfo() {
		Response res=given()
		
		.when()
		.get("https://www.google.com/");
		
//		.then()
//		.cookie("AEC","AUEFqZdn-12SH1B77F9PbZjowhXUJtahXKe42K3GXeaDTPTIZ2TVBbp6rxU")
//		.log().all();
		
		//get info of single cookie
		String cookie_value=res.getCookie("AEC");
		System.out.println("Value of Cookie is=====> "+cookie_value);
		
		//get info of all the cookies
		Map<String, String> allcookies=res.getCookies();
		//for every cookies name we write this keyset method
		System.out.println(allcookies.keySet());
		//for printing all the values of cookies we use a for loop
		for(String cookies_name:allcookies.keySet())//here we are extracting all the cookie name and storing them into a variable 
			{
			//here we are calling all the info using their cookie name using getcookie method and storing it into a string variable
			String cookie_values=res.getCookie(cookies_name);
			//here we are printing the cookies name and values
			System.out.println(cookies_name/*this is for cookie name*/+"    "+cookie_values/*this is for all the cookies values*/);
		}
	}
}
