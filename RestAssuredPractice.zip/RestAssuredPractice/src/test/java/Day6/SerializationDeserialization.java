package Day6;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import Day2.POJO_postRequest;

//POJO to JSON is Serialization and JSON to POJO is deserialization 
public class SerializationDeserialization {
	//Pojo to json(Serialization)
	@Test
	public void convertPojo2json() throws Exception  {
		StudentPojo stupojo = new StudentPojo();
		
		stupojo.setName("scott");
		stupojo.setLocation("France");
		stupojo.setPhone("123456789098");
		String Coursearr[]= {"C","C++"};
		stupojo.setCourses(Coursearr);
		
		//convert java object to json Object 
		ObjectMapper objmapp=new ObjectMapper(); 
		String jsondata;
			jsondata = objmapp.writerWithDefaultPrettyPrinter().writeValueAsString(stupojo);
			System.out.println(jsondata);
	}
	
	//json to pojo(Deserialization)
	@Test
	public void convertjson2pojo() throws JsonProcessingException {
		
		String jsondata="{\r\n"
				+ "  \"name\" : \"scott\",\r\n"
				+ "  \"location\" : \"France\",\r\n"
				+ "  \"phone\" : \"123456789098\",\r\n"
				+ "  \"courses\" : [ \"C\", \"C++\" ]\r\n"
				+ "}";
				
		//Convert jsondata to pojo object
		ObjectMapper obj=new ObjectMapper();
		StudentPojo st=obj.readValue(jsondata, StudentPojo.class); //reading the data from json and creating a studentpojo class object and storing it into another student object
		System.out.println("Name:"+st.getName());
		System.out.println("Location:"+st.getLocation());
		System.out.println("Phone:"+st.getPhone());
		System.out.println("Course 1:"+st.getCourses()[0]);
		System.out.println("Course 2:"+st.getCourses()[1]);
	}
}
