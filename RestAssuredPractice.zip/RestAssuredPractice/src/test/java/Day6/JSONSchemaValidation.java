package Day6;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.module.jsv.JsonSchemaValidator;
public class JSONSchemaValidation {
	@Test
	public void jsonschemavalidation() {
		given()
		
		.when()
		.get("http://localhost:3000/store")
		
		.then()
		.assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("storeJsonSchema1.json"));//to validate the schema 1st we have to fetch the json schema from json file using converter then we need to save it inside out test/resourses package then we need to use this syntax
	}
	
}
