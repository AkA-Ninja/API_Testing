package api.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.UserEndPoints;
import api.payload.User;
import api.utils.DataProviders;
import io.restassured.response.Response;

public class DDTests {
	
	@Test(priority=1,dataProvider="Data",dataProviderClass=DataProviders.class) //in order to get the data from excel we created dataproviders class and we need to use this syntax inorder to fetch the data
	public void testPostUser(String UserID,String userName,String fName,String lName,String Email,String password,String ph) {
		User userPayload=new User();
		userPayload.setId(Integer.parseInt(UserID));
		userPayload.setUsername(userName);
		userPayload.setFirstName(fName);
		userPayload.setLastName(lName);
		userPayload.setEmail(Email);
		userPayload.setPassword(password);
		userPayload.setPhone(ph);
		
		Response response=UserEndPoints.createUser(userPayload);
		
		Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=2,dataProvider = "UserNames",dataProviderClass = DataProviders.class)
	public void testGetUser(String username) {
		Response res=UserEndPoints.readUser(username);
		Assert.assertEquals(res.getStatusCode(), 200);
	}
	@Test(priority=3,dataProvider = "UserNames",dataProviderClass = DataProviders.class)
	public void testDeleteUser(String username) {
		Response res=UserEndPoints.deleteUser(username);
		Assert.assertEquals(res.getStatusCode(), 200);
}
}
